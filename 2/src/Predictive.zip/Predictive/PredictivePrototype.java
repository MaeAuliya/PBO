package Predictive;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class PredictivePrototype {
//to check if it alphabetic or not
	private static boolean isValidWord(String word) {
		for (int i=0; i < word.length(); i++) {
			if ((word.charAt(i) >= 97 &&  word.charAt(i) <= 122) || (word.charAt(i) >= 65 &&  word.charAt(i) <= 90)){
			}else
				return false;
		}
		return true;
	}

//1.
	public static String wordToSignature(String a) {
		StringBuffer scan = new StringBuffer ("");
		
		a = a.toLowerCase();
		
		for(int i=0; i<a.length(); i++) {
			if(a.charAt(i) >= 97 && a.charAt(i) <= 99 )
				scan.append(2);
			else if(a.charAt(i) >= 100 && a.charAt(i) <= 102)
				scan.append(3);
			else if(a.charAt(i) >= 103 && a.charAt(i) <= 105)
				scan.append(4);
			else if(a.charAt(i) >= 106 && a.charAt(i) <= 108)
				scan.append(5);
			else if(a.charAt(i) >= 109 && a.charAt(i) <= 111)
				scan.append(6);
			else if(a.charAt(i) >= 112 && a.charAt(i) <= 115)
				scan.append(7);
			else if(a.charAt(i) >= 116 && a.charAt(i) <= 118)
				scan.append(8);
			else if(a.charAt(i) >= 119 && a.charAt(i) <= 122)
				scan.append(9);
			else
				scan.append(" ");
		}
		return scan.toString();
	}

//2.
	public static Set<String> signatureToWords(String signature){
		Set<String> h = new HashSet<String>();

		try {
			File dictionary = new File("words.txt");
			Scanner dc = new Scanner(dictionary);
			
			while(dc.hasNextLine()) {
				String data = dc.nextLine();
				
				if(isValidWord(data) && (data.length() == signature.length())) {
					boolean temp = true;
					for (int i=0; i<signature.length(); i++) {
						int p1=0,p2=0,p3=0,p4=0;
						if(signature.charAt(i) == '2') {
							p1=97;
							p2=98;
							p3=99;
							p4=p3;
						}else if(signature.charAt(i) == '3') {
							p1=100;
							p2=101;
							p3=102;
							p4=p3;
						}else if(signature.charAt(i) == '4') {
							p1=103;
							p2=104;
							p3=105;
							p4=p3;
						}else if(signature.charAt(i) == '5') {
							p1=106;
							p2=107;
							p3=108;
							p4=p3;
						}else if(signature.charAt(i) == '6') {
							p1=109;
							p2=110;
							p3=111;
							p4=p3;
						}else if(signature.charAt(i) == '7') {
							p1=112;
							p2=113;
							p3=114;
							p4=115;
						}else if(signature.charAt(i) == '8') {
							p1=116;
							p2=117;
							p3=118;
							p4=p3;
						}else if(signature.charAt(i) == '9') {
							p1=119;
							p2=120;
							p3=121;
							p4=122;
						}
						data = data.toLowerCase();
						if(data.charAt(i)<p1 || data.charAt(i)>p4) {
							temp = false;
							break;
						}
					}
					if(temp)
						h.add(data);
				}
			}
			dc.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("An error occurred.");
		    e.printStackTrace();
		}
		return h;
	}
}
