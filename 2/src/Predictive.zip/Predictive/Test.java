package Predictive;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;


public class Test {
	public static void main (String[] args) {
		PredictivePrototype word = new PredictivePrototype();
		String a = "43556";
//		System.out.println("Possible Signature = " + word.wordToSignature(a));
		System.out.println("possible word : " + word.signatureToWords(a));
	}
	
}
