package Predictive;

public class Sigs2WordsProto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PredictivePrototype word = new PredictivePrototype();
		
		for(int i=0; i<args.length; i++) {
			System.out.print(args[i] + " ");
		}
		
		System.out.println();
		for(int i=0; i<args.length; i++) {
			System.out.println();
			System.out.print(args[i] + " : " + word.signatureToWords(args[i]) + " ");
		}
	}
}
